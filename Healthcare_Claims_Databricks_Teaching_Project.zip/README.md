# Healthcare Claims Data Modernization — SQL Server to Databricks

A small, teaching-friendly Data Engineering project inspired by common SQL Server-to-Databricks migration patterns.

> **Important:** This is an independently created demonstration project using synthetic data. It does not contain client code, client data, credentials, or proprietary configuration.

## Business Scenario

A healthcare organization stores claims data in a legacy SQL Server system.

The data team wants to modernize the workload by moving the transformation logic to Databricks.

### Legacy

SQL Server
- Patients
- Providers
- Claims
- SQL views
- Reporting transformations

### Target

Databricks
- Databricks SQL
- PySpark
- Delta tables
- Unity Catalog-style organization
- Workflow orchestration
- Data validation

## Architecture

```text
Synthetic CSV / SQL Server
          |
          v
     Raw Claims Data
          |
          v
   SQL Transformation
          |
          v
 Databricks SQL / PySpark
          |
          v
     Curated Claims
          |
          +------> Validation
          |
          v
    Provider Summary
          |
          v
     Output Report
```

## Learning Objectives

By completing this project, a student should be able to:

1. Understand a basic ETL pipeline.
2. Write SQL joins and aggregations.
3. Understand SQL Server-to-Databricks migration concepts.
4. Implement PIVOT using conditional aggregation.
5. Build a PySpark DataFrame transformation.
6. Perform source-to-target validation.
7. Understand catalog/schema/table organization.
8. Understand workflow orchestration concepts.
9. Use Git to manage project code.

## Project Structure

```text
sql-server/
  01_create_tables.sql
  02_create_view.sql
  03_pivot.sql

pyspark/
  claims_etl.py

validation/
  reconciliation.sql

argo/
  cronworkflow.yaml

sample-data/
  patients.csv
  providers.csv
  claims.csv
```

## Teaching Flow

### Session 1 — SQL

- Create tables
- Load synthetic data
- Create a view
- Explain JOIN
- Explain CASE
- Explain GROUP BY
- Explain PIVOT

### Session 2 — Databricks / PySpark

- Read the claims data
- Filter paid claims
- Join providers
- Aggregate by provider
- Write curated output

### Session 3 — Validation

- Compare row counts
- Compare distinct IDs
- Check NULLs
- Check duplicates
- Compare business totals

### Session 4 — Orchestration

- Explain workflow concepts
- Read the Argo CronWorkflow YAML
- Explain schedule, parameters and dependencies

## Expected Final Result

The student should produce a provider-level summary such as:

| provider_id | provider_name | specialty | claim_count | total_paid |
|---|---|---|---:|---:|
| PR001 | Dr. Rao | Cardiology | 3 | 6650.00 |
| PR002 | Dr. Chen | Orthopedics | 2 | 3400.00 |

## Interview Questions

1. Why migrate SQL Server workloads to Databricks?
2. What is the difference between SQL Server and SSMS?
3. What is a LEFT JOIN?
4. Why can a JOIN increase row counts?
5. UNION vs UNION ALL?
6. What is PIVOT?
7. How can PIVOT be implemented using CASE?
8. What is a Spark DataFrame?
9. What is lazy evaluation?
10. What is a shuffle?
11. How would you validate a migration?
12. What is Unity Catalog?
13. What is a workflow?
14. What is a CronWorkflow?
15. How would you troubleshoot a failed pipeline?

## Portfolio Note

This project is intentionally small enough to teach but demonstrates the same fundamental engineering lifecycle used in larger modernization projects:

```text
Understand
   ↓
Convert
   ↓
Transform
   ↓
Validate
   ↓
Orchestrate
   ↓
Deliver
```
